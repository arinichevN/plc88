#ifndef APP_DEBUG_H
#define APP_DEBUG_H

#include "../../lib/debug.h"

extern int appdebug_begin();

#endif 

