#ifndef APP_SERVER_H
#define APP_SERVER_H

#include "../../lib/debug.h"
#include "../modules/main.h"

extern int appserver_begin();

extern void appserver_control();

#endif
