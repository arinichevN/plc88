
appdefbut_state_t appdefbut_read() {return DEFAULT_BUTTON_UNKNOWN;}

int appdefbut_begin(){return 0;}
