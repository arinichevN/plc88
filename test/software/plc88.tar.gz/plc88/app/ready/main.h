#ifndef APP_READY_H
#define APP_READY_H

extern void appready_on();
extern void appready_off();
extern int appready_begin();

#endif 

