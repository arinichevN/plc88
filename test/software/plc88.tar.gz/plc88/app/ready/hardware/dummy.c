
void appready_on(){;}

void appready_off(){;}

int appready_begin(){return 0;}
