#include "main.h"

#ifdef CPU_MODULE_ATMEGA2560
#include "hardware/atmega2560.c"
#else
#include "hardware/dummy.c"
#endif


