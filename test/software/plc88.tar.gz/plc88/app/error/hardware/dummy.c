
void apperror_on(){;}

void apperror_off(){;}

int apperror_begin(){return 0;}
