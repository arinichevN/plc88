#ifndef APP_ERROR_H
#define APP_ERROR_H

extern void apperror_on();
extern void apperror_off();
extern int apperror_begin();

#endif 

