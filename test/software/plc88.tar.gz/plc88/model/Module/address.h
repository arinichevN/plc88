#ifndef MODEL_MODULE_ADDRESS_H
#define MODEL_MODULE_ADDRESS_H

#define MODULE_ADDRESS_MIN		1
#define MODULE_ADDRESS_MAX		255
#define MODULE_ADDRESS_UNKNOWN	0

typedef uint8_t module_address_t;

#endif

